from Protocol.Commands.Server.LogicGiveDeliveryItemsCommand import LogicGiveDeliveryItemsCommand
from Protocol.Commands.Server.LogicDiamondsAddedCommand import LogicDiamondsAddedCommand

commands = {
    203: LogicGiveDeliveryItemsCommand,
    202: LogicDiamondsAddedCommand,
}