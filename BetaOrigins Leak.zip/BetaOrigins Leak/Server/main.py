ascii_art = """
    ____       __        ____       _       _
   / __ )___  / /_____ _/ __ \_____(_)___ _(_)___  _____
  / __  / _ \/ __/ __ `/ / / / ___/ / __ `/ / __ \/ ___/
 / /_/ /  __/ /_/ /_/ / /_/ / /  / / /_/ / / / / (__  )
/_____/\___/\__/\__,_/\____/_/  /_/\__, /_/_/ /_/____/
                                  /____/
"""

print(ascii_art)

from Network.Server import Server
from DataBase.DataBase import DataBase
from random import randint as r
#DataBase.loadAll()
import os
import json


print("Starting Server...")
print("V11 (Leaked by wileee1337)")

server = Server()
server.start()